import React from "react";
import "./Signup.css";

const Signup = ({ onClose }) => {
  return (
    <div className="signup-overlay">
      <div className="signup-modal">
        <div className="signup-header">
          <h2 className="signup-title">Signup to Your Account</h2>
          <button className="close-button" onClick={onClose}>✕</button>
        </div>
        <div className="signup-body">
          <form className="signup-form">
            <div className="form-group">
              <label className="form-label">Email</label>
              <input type="email" className="form-control" placeholder="your@email.com" required />
            </div>
            <div className="form-group">
              <label className="form-label">Password</label>
              <input type="password" className="form-control" placeholder="••••••••" required />
            </div>
            <div className="remember-me">
              <input type="checkbox" id="remember" />
              <label htmlFor="remember">Remember me</label>
            </div>
            <button type="submit" className="signup-button">Signup</button>
          </form>
          <div className="signup-footer">
            <a href="#" className="forgot-password">Forgot Password?</a>
            <p className="signup-link">Don't have an account? <a href="#">Sign Up</a></p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Signup;